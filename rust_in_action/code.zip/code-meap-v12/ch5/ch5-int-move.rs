fn main() {
  let a = Box::new(10);
  let b = a;
  let c = a;
}
