fn main() {
  let (a, b) = (200, 200);
  let c: u8 = a + b; // <1>
  println!("200 + 200 = {}", c);
}