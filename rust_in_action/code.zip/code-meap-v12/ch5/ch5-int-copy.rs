fn main() {
    let a = 10;
    let b = a + 1;
    let c = a + 2;
}
