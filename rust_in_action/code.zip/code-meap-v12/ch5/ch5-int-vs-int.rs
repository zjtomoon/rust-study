fn main() {
    let a: u16 = 50115;
    let b: i16 = -15421;
  
    println!("a: {:016b} {}", a, a);  // <1>
    println!("b: {:016b} {}", b, b);  // <1>
  }