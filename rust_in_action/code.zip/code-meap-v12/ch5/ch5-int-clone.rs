fn main() {
  let a = Box::new(10);
  let b = a.clone();
  let c = a;
}
