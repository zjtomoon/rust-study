fn err() -> ! {
    panic!();
}

fn main() {
    err();
}