#[allow(unused)]

fn main() {
  let mut i: u16 = 0;
  loop {
      i += 1;
  }
}
