set +x

sudo ip tuntap del mode tap name tap-rust