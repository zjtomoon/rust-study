use std::net::SocketAddrV4;
use std::sys::platform;

fn main() {
    let addr: SocketAddrV4 = "192.168.0.1:80".parse().unwrap();
    let platform::
    println!("Hello, world!");
}
