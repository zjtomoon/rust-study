fn main() {
  println!("ok")
}

